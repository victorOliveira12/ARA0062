<html>
    <head>
        <meta charset = "utf8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <title>Swift Hotel</title>
        <style>
			ul{
				list-style-type:none;
				padding:0;
				margin:0;
				background-color:#ff0050;
				overflow:hidden;
				text-align:center;
			}
			li{display:inline-block;}
			li a{
				display:block;
				color:white;
				padding:18px 18px;
				text-decoration:none !important;
				transition:0.4s;
				font-family:'Arial', 'sans-serif';
				font-weight:bold;
				font-size:14px;
			}
			li a:active, a:hover{background-color:#ff5d8d; color:white;}
			#headerth{
			    background:url(https://mathborges.000webhostapp.com/hotelmvn8.jpg);
			    background-attachment: fixed;
			    height:160px;
			    background-size:cover;
			    display:block;
			    font-size:200% !important;
			    font-family:'Tahoma','sans-serif';
			    
			}
			h1, #headerlink{
			    width: 420px;
                height: 70px;
                text-shadow: 0px 0px 3px #1d1d1d;
                font-size:4rem;
			}
			a{text-decoration:none!important;}*{margin:0;padding:0;} p{margin:5px;}
			
			</style>
    </head>
    
    <body>
        <center>
            <div id="headerth">
                <div id="headerlink">
                    <a href="/">
                        <h1 class="animate__animated animate__fadeInUp" style="color:white; padding-top:28;">Swift Hotel</h1>
                    </a>
                </div>
            </div>
        </center>
        <div id="menu">
            <ul>
                <li><a href="/sobre.html">O Hotel</a></li>
                <li><a href="/trabalho/login.html">Conectar-se</a></li>
                <li><a href="/prec.html">Preços</a></li>
                <li><a href="/form.htm">Reservas</a></li>
            </ul>
        </div>
        
        <?php
        
        include_once("trabalho/bd2.php");
$sql = "SELECT id, corpo, titulo FROM Blog";
$resultset = mysqli_query($db, $sql) or die("database error:". mysqli_error($db));
while( $record = mysqli_fetch_assoc($resultset) ) {
 ?>

    <div class="row justify-content-center" style="display:inline-block;">
         <div class="col-5">
     <div class='card' style='width: 18rem;'>
   <div class='card-body'>
    <h5 class='card-title'><?php echo $record['titulo']; ?></h5>
    <p class='card-text'><?php echo $record['corpo']; ?></p>
    <a href='/' class='btn btn-primary'>Go somewhere</a>
  </div>
</div>
</div>
</div> 

<?php } ?>       

          
       </body>
</html>