<head>
    <style>
        h1{font-family:sans-serif;color:#333333; text-align:center;}
        a:not(.textobranco){text-decoration:none;color:#333333;}
        a{text-decoration:none; color:white; font-family:sans-serif;}
        #voltar{
            text-align:center; 
            background-color:#ff0050; 
            font-weight:bold; 
            padding:1rem;
            color:white;
        }
    </style>
</head>
<?php

include_once "../servico/Bd.php";

$erro_senha = $erro_nome = "";

$login=$_POST['login'];
$senha=$_POST['senha'];


if(empty(trim($_POST["login"]))){
       echo $erro_nome = "<h1>Por favor, insira um nome de usuário.</h1>";
}
else if(empty(trim($_POST["senha"]))){
       echo $erro_senha = "<h1>Por favor, insira uma senha.</h1>";
}
else if(strlen(trim($_POST["senha"])) < 8){
       echo $erro_senha = "<h1>A senha deve ser maior que 6 caracteres.</h1>";
}

else{
       $sql = "INSERT INTO `Usuario` (`id`, `usuario`, `senha`) VALUES (NULL, '$login', '$senha')";    
       echo "<h1>Registro feito com sucesso, seja bem-vindo, $login.</h1>";

       $bd = new Bd();
       $contador = $bd->exec($sql);
}

?>
<div class="container">
  <div class="row">
    <div id="voltar" class="col-sm">
      <a class="textobranco" style:"color:white;" href="../login.html">Conectar-se</a>
    </div>
  </div>
</div>

